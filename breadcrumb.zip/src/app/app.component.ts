import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'test-app';
  breadCrumbId : number = 0;
  results : EventEmitter<any> = new EventEmitter()
  receivedId$: Observable<number> = new Observable;

ngOnInit(): void {
  setTimeout(() => {
    this.results.emit(['Hello', "123", "How", "are", "you"])
  }, 100);
  this.receivedId$.subscribe(ele=>{
    this.breadCrumbId = ele; 
  })
}
}
