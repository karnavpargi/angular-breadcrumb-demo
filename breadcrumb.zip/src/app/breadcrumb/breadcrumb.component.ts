import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable, Observer } from 'rxjs';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {
  @Input('updateBreadCrumb') public results$: Observable<any> = new Observable();
  data: any[] = []
  ngOnInit(): void {
    this.results$.subscribe(ele => {
      this.data = [...this.data, ...ele]
    })
  }

  goBack(index: number) {
    this.data = this.data.slice(0, index + 1)
    console.log(this.data[index])
  }
}
